package Week1.IfStatements;

public class ALittleQuiz {
}
