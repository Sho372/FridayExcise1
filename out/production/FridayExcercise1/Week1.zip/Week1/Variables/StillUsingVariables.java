package Week1.Variables;

public class StillUsingVariables {

  public static void main(String[] args) {
    printNameAndYear("Shohei Mizuno", "2012");
  }

  static void printNameAndYear(String name, String year) {
    System.out.println("My name is " + name + " and I'll graduate in " + year);
  }
}
