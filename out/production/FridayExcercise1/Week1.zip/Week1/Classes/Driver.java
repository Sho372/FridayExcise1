package Week1.Classes;

public class Driver {

  public static void main(String[] args) {
    Rectangle r1 = new Rectangle(5, 7, "Blue");
    Rectangle r2 = new Rectangle(5, 7, "Green");
    Rectangle r3 = new Rectangle(5, 7, "Red");
    r1.draw();
  }
}
